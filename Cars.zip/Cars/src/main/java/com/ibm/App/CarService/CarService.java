package com.ibm.App.CarService;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ibm.App.CarEntity.Cars;
import com.ibm.App.CarRepository.CarsRepository;

@Service
public class CarService {

	@Autowired
	CarsRepository carRepo;
		
	public List<Cars> getCarsByCity(String city) {
		return carRepo.findByCity(city);
	}
	
	public Optional<Cars> getCarById(int id) {
		return carRepo.findById(id);
	}
	
	public List<Cars> getCarsByArea(String location) {
		return carRepo.findByLocation(location);
	}
	
	
}

