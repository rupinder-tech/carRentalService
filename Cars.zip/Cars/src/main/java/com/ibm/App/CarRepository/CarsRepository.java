package com.ibm.App.CarRepository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.ibm.App.CarEntity.Cars;

public interface CarsRepository extends CrudRepository<Cars, Integer> {

	List<Cars> findByCity(String city);
	
	List<Cars> findByLocation(String location);

}
