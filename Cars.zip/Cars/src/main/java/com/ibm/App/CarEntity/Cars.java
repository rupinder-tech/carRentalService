package com.ibm.App.CarEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Cars {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "model_no")
	Integer id;
	
	int numOfSeats;
	String carName, transmissionType, fuelType, location, carType, pricePerKm, bookingPrice, imageUrl, city;
	Boolean isBooked;
	
	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public Boolean getisBooked() {
		return isBooked;
	}

	public void setisBooked(Boolean isBooked) {
		this.isBooked = isBooked;
	}

	public String getimageUrl() {
		return imageUrl;
	}

	public void setimgUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	Cars(){}

	public int getNumOfSeats() {
		return numOfSeats;
	}

	public void setNumOfSeats(int numOfSeats) {
		this.numOfSeats = numOfSeats;
	}

	public String getcarName() {
		return carName;
	}

	public void setcarName(String carName) {
		this.carName = carName;
	}

	public String gettransmissionType() {
		return transmissionType;
	}

	public void settransmissionType(String transmissionType) {
		this.transmissionType = transmissionType;
	}

	public String getfuelType() {
		return fuelType;
	}

	public void setfuelType(String fuelType) {
		this.fuelType = fuelType;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getcarType() {
		return carType;
	}

	public void setcarType(String carType) {
		this.carType = carType;
	}

	public String getpricePerKm() {
		return pricePerKm;
	}

	public void setpricePerKm(String pricePerKm) {
		this.pricePerKm = pricePerKm;
	}

	public String getbookingPrice() {
		return bookingPrice;
	}

	public void setbookingPrice(String bookingPrice) {
		this.bookingPrice = bookingPrice;
	}

	public Integer getId() {
		return id;
	}

}
