package com.ibm.App.CarController;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ibm.App.CarEntity.Cars;
import com.ibm.App.CarService.CarService;

@RestController
public class CarsController {

	@Autowired
	CarService service;
	
	@RequestMapping("cars/list/{city}")
	List<Cars> getCarsByCity(@PathVariable String city){
		return service.getCarsByCity(city);
	}
	
	@RequestMapping("cars/list/city/{location}")
	List<Cars> getCarsByArea(@PathVariable String location){
		return service.getCarsByArea(location);
	}
	
	@RequestMapping("cars/{id}")
	Optional<Cars> getCarById(@PathVariable int id) {
		return service.getCarById(id);
	}
}
