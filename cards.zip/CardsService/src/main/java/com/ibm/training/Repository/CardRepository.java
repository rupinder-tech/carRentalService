package com.ibm.training.Repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.ibm.training.Entity.CardsDetails;

@Repository
public interface CardRepository extends CrudRepository<CardsDetails, Integer> {

	List<CardsDetails> findByUserUserId(Integer userId);
	
}
