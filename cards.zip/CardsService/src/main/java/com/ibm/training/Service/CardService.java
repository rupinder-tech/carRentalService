package com.ibm.training.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ibm.training.Entity.CardsDetails;
import com.ibm.training.Entity.User;
import com.ibm.training.Repository.CardRepository;

@Service
public class CardService {

	@Autowired
	CardRepository repo;

	public void addCard(CardsDetails card, Integer userId) {
		card.setUser(new User(userId));
		repo.save(card);
	}

	public List<CardsDetails> getCardsByUserId(Integer userId) {
		return repo.findByUserUserId(userId);
	}

	public void deleteCardById(int cardId) {
			repo.deleteById(cardId);
	}
}
