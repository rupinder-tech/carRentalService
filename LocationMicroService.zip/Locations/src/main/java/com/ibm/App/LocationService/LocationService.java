package com.ibm.App.LocationService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ibm.App.LocationEntity.Locations;
import com.ibm.App.LocationRepository.LocationRepository;

@Service
public class LocationService {

	@Autowired
	LocationRepository repo;

	public List<Locations> getLocationsByCity(String city) {
		return repo.findByCity(city);
	}
}
