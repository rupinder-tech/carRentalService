package com.ibm.App.LocationController;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ibm.App.LocationEntity.Locations;
import com.ibm.App.LocationService.LocationService;

@RestController
public class LocationController {

	@Autowired
	LocationService service;
	
	@RequestMapping("/locations/{city}")
	 List<Locations> getLocationsByCity(@PathVariable String city){
		return service.getLocationsByCity(city);
	}
	
}
